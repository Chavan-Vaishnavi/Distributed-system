import java.util.*;

class TokenRing {
    private List<String> processIds;
    private String tokenHolder;

    public TokenRing(List<String> processIds) {
        System.out.println("Unordered list of processes: " + processIds);
        Collections.sort(processIds); // Sorting process IDs to form an ordered ring
        System.out.println("Ordered ring structure: " + processIds);
        this.processIds = processIds;
        this.tokenHolder = processIds.get(0); // Initially assigning token to first process
        displayRing();
    }

    private void displayRing() {
        System.out.print("Ring structure with token: ");
        for (String process : processIds) {
            if (process.equals(tokenHolder)) {
                System.out.print("(" + process + ") ");
            } else {
                System.out.print(process + " ");
            }
        }
        System.out.println();
    }

    public void passToken() {
        Scanner scanner = new Scanner(System.in);
        int index = 0;
        while (true) {
            String process = processIds.get(index);
            System.out.print("Process " + process + ", do you want to take the token? (yes/no): ");
            String response = scanner.nextLine().trim().toLowerCase();
            if (response.equals("yes")) {
                System.out.println("Process " + process + " has taken the token.");
                tokenHolder = process;
                displayRing();
                enterCriticalSection(process);
                break;
            } else {
                System.out.println("Process " + process + " declined the token.");
            }
            index = (index + 1) % processIds.size(); // Move token to next process in ring
        }
        scanner.close();
    }

    private void enterCriticalSection(String process) {
        System.out.println("Process " + process + " is entering the critical section.");
        try {
            Thread.sleep(2000); // Simulating critical section execution
        } catch (InterruptedException e) {
            System.out.println("An error occurred in the critical section.");
        }
        System.out.println("Process " + process + " is leaving the critical section.");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        List<String> processIds = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter process ID for process " + (i + 1) + ": ");
            String pid = scanner.nextLine();
            processIds.add(pid);
        }
        
        System.out.println("Processes entered (unordered): " + processIds);
        
        TokenRing ring = new TokenRing(processIds);
        ring.passToken();
        scanner.close();
    }
}
