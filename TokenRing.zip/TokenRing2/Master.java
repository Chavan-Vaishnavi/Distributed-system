import java.util.*;

class Master {
    private List<String> processIds;

    public Master(List<String> processIds) {
        System.out.println("Unordered list of processes: " + processIds);
        Collections.sort(processIds);
        System.out.println("Ordered list of processes: " + processIds);
        this.processIds = processIds;
    }

    public void startTokenPassing() {
        int index = 0;
        int totalProcesses = processIds.size();
        while (true) {
            String currentProcess = processIds.get(index);
            Slave slave = new Slave(currentProcess);
            if (slave.requestToken()) {
                slave.enterCriticalSection();
                break;
            }
            index = (index + 1) % totalProcesses; // Move to the next process in the ring
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();
        scanner.nextLine();
        
        List<String> processIds = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter process ID for process " + (i + 1) + ": ");
            String pid = scanner.nextLine();
            processIds.add(pid);
        }
        
        System.out.println("Processes entered (unordered): " + processIds);
        
        Master master = new Master(processIds);
        master.startTokenPassing();
        scanner.close();
    }
}