import java.util.Scanner;

class Slave {
    private String processId;

    public Slave(String processId) {
        this.processId = processId;
    }

    public boolean requestToken() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Process " + processId + ", do you want to take the token? (yes/no): ");
        String response = scanner.nextLine().trim().toLowerCase();
        return response.equals("yes");
    }

    public void enterCriticalSection() {
        System.out.println("Process " + processId + " is entering the critical section.");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println("An error occurred in the critical section.");
        }
        System.out.println("Process " + processId + " is leaving the critical section.");
    }
}
