import java.io.*;
import java.net.*;
import java.util.Scanner;

public class BerkeleyClient {
    private static final String SERVER_IP = "127.0.0.1"; // Change if needed
    private static final int PORT = 5000;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_IP, PORT)) {
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            // Step 1: Get user input for local time
            System.out.print("Enter client's current time (HH MM): ");
            int hours = scanner.nextInt();
            int minutes = scanner.nextInt();
            int[] localTime = {hours, minutes};
            System.out.println("Client's current time: " + formatTime(localTime[0], localTime[1]));
            
            out.writeInt(localTime[0]); // Send hours
            out.writeInt(localTime[1]); // Send minutes
            out.flush(); // Ensure data is sent before reading

            // Step 2: Receive time adjustment from server
            int hourAdjustment = in.readInt();
            int minuteAdjustment = in.readInt();
            int adjustedHours = in.readInt();
            int adjustedMinutes = in.readInt();

            System.out.println("Time adjustment received: " + formatTime(hourAdjustment, minuteAdjustment));
            System.out.println("Client's adjusted time: " + formatTime(adjustedHours, adjustedMinutes));

        } catch (EOFException e) {
            System.out.println("Server closed the connection unexpectedly.");
        } catch (IOException e) {
            System.out.println("Error connecting to server.");
            e.printStackTrace();
        }
    }

    private static String formatTime(int hours, int minutes) {
        return String.format("%02d:%02d", hours, minutes);
    }
}
